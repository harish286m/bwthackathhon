# Hostel Mess Management System

A Django web app for a college hostel: students, rooms, weekly menus, meal attendance, mess fees,
complaints, food-waste monitoring and reports. Three roles (Warden/Admin, Mess Staff, Student) with
server-side permission checks. SQLite database, Bootstrap 5, Chart.js.

## 1. Folder structure

```
hostel_mess/
|-- manage.py
|-- requirements.txt
|-- README.md
|-- config/                 settings.py, urls.py, wsgi.py, asgi.py
|-- mess/                   the application
|   |-- models.py           all database models
|   |-- forms.py            validated forms
|   |-- permissions.py      role_required decorator (server-side access control)
|   |-- views.py            all views (admin, staff, student)
|   |-- urls.py             URL routes
|   |-- context.py          role-based sidebar
|   |-- admin.py            Django admin registration
|   |-- tests.py            28 automated tests
|   |-- migrations/         0001_initial, 0002_default_meal_sessions
|   `-- management/commands/seed_demo.py
|-- templates/              base layout, partials, and one template per page
`-- static/                 css/app.css, js/app.js
```

## 2. Set up on Windows (PowerShell, VS Code)

Requires Python 3.10 or newer (check with `python --version`). Open the `hostel_mess` folder in VS Code,
then open a terminal (Terminal > New Terminal) and run:

```powershell
python -m venv venv
venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py seed_demo
python manage.py runserver
```

Open **http://127.0.0.1:8000/** in your browser. Stop the server with Ctrl+C.

Charts, icons and fonts load from CDNs, so you need an internet connection when viewing the pages.

## 3. Demo logins (development only)

| Role | Username | Password |
|---|---|---|
| Admin / Warden | `demo_admin` | `DemoPass@2026` |
| Mess Staff | `demo_staff` | `DemoPass@2026` |
| Student | `demo_student` | `DemoPass@2026` |

The other 29 demo students are `hm2026002` to `hm2026030` with the same password.
Use `python manage.py seed_demo --password "YourOwnPassword"` to choose a different demo password.
**These credentials are for local demos only. Change them (use "Change password" in the top-right menu)
and never deploy with them.**

`seed_demo` is safe to run again: it updates or skips existing records and never duplicates them.
Demo dates are relative to today, so re-run it to refresh the data when you open the project on a new day.

To create your own real warden account instead:

```powershell
python manage.py createsuperuser
```
A superuser without a profile is treated as Admin.

## 4. What each role can do

**Admin / Warden**: dashboard; add, edit, search, filter and remove students (a login with a one-time
temporary password is created for each new student); rooms; weekly menus; attendance reports with CSV;
monthly fees and simulated payments; expenses; complaints with responses; food-waste monitoring;
monthly reports with six charts and CSV exports; audit log.

**Mess Staff**: today's menu and sessions, mark attendance per meal (duplicates are blocked by the
database), correct mistakes with a reason (recorded in the audit log), record meals prepared / served /
leftover, and see a demand estimate that accounts for students' planned absences.

**Student**: personal dashboard, weekly menu, own attendance, fee balance and payment history,
submit complaints and see their status and the warden's response, and plan meal absences.

## 5. Run the tests

```powershell
python manage.py test
```
Covers login and logout, role permissions (including blocked POSTs), duplicate attendance, attendance
corrections and audit trail, fee status/balance/overpayment rules, waste percentage and estimates,
re-runnable demo data, and a load test of every page for every role.

## 6. Troubleshooting

| Problem | Fix |
|---|---|
| `python` is not recognized | Reinstall Python from python.org and tick "Add Python to PATH", or try `py -m venv venv`. |
| `Activate.ps1 cannot be loaded because running scripts is disabled` | Run `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`, answer Y, then activate again. Or use `venv\Scripts\activate.bat` in Command Prompt. |
| `No module named django` | The virtual environment is not active (no `(venv)` in the prompt). Activate it and run `python -m pip install -r requirements.txt`. |
| `no such table` errors | Run `python manage.py migrate`. |
| Login page works but dashboards show no meals or sessions | Run `python manage.py migrate` (it creates the four meal sessions), then `python manage.py seed_demo`. |
| Charts or icons are missing | The page could not reach the CDN. Check your internet connection. |
| `Error: That port is already in use` | Use another port: `python manage.py runserver 8001`. |
| Want a clean slate | Stop the server, delete `db.sqlite3`, then run `migrate` and `seed_demo` again. |
| Forgot a password | `python manage.py changepassword demo_admin` |

## 7. Notes for deployment

- Set the environment variables `DJANGO_SECRET_KEY` (a long random value), `DJANGO_DEBUG=0` and
  `DJANGO_ALLOWED_HOSTS`. With `DJANGO_DEBUG=0` the app refuses to start without a custom secret key.
- Serve over HTTPS and enable secure cookies; use a production web server and static-file setup.
- Payments are simulated: the app only records a payment entry. It never stores card or bank details.
- Wastage percentages and demand figures are estimates and are labelled as such in the interface.
