"""Database models for the Hostel Mess Management System."""
from decimal import Decimal

from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator, RegexValidator
from django.db import models
from django.db.models import Sum, Value
from django.db.models.functions import Coalesce

ZERO = Decimal("0.00")
phone_validator = RegexValidator(r"^\+?[0-9 ]{10,15}$", "Enter a valid phone number (10-15 digits).")
student_id_validator = RegexValidator(r"^[A-Za-z0-9-]{4,20}$", "Use 4-20 letters, digits or hyphens.")


class Role(models.TextChoices):
    ADMIN = "ADMIN", "Admin / Warden"
    STUDENT = "STUDENT", "Student"
    STAFF = "STAFF", "Mess Staff"


class Profile(models.Model):
    """Attaches a role to a Django user."""
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="profile")
    role = models.CharField(max_length=10, choices=Role.choices)
    phone = models.CharField(max_length=20, blank=True, validators=[phone_validator])

    def __str__(self):
        return f"{self.user} ({self.get_role_display()})"


class HostelRoom(models.Model):
    number = models.CharField(max_length=10, unique=True)
    block = models.CharField(max_length=20, default="A")
    capacity = models.PositiveSmallIntegerField(default=4, validators=[MinValueValidator(1)])

    class Meta:
        ordering = ["block", "number"]

    def __str__(self):
        return f"{self.block}-{self.number}"


class Student(models.Model):
    class Department(models.TextChoices):
        CSE = "CSE", "Computer Science"
        IT = "IT", "Information Technology"
        ECE = "ECE", "Electronics"
        MECH = "MECH", "Mechanical"
        CIVIL = "CIVIL", "Civil"

    user = models.OneToOneField(settings.AUTH_USER_MODEL, null=True, blank=True,
                                on_delete=models.SET_NULL, related_name="student")
    student_id = models.CharField(max_length=20, unique=True, validators=[student_id_validator])
    full_name = models.CharField(max_length=100)
    department = models.CharField(max_length=10, choices=Department.choices)
    year = models.PositiveSmallIntegerField(choices=[(i, f"Year {i}") for i in range(1, 5)])
    room = models.ForeignKey(HostelRoom, on_delete=models.PROTECT, related_name="students")
    contact = models.CharField(max_length=20, validators=[phone_validator])
    email = models.EmailField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["full_name"]
        indexes = [models.Index(fields=["department", "year"])]

    def __str__(self):
        return f"{self.full_name} ({self.student_id})"


class MessRegistration(models.Model):
    class Diet(models.TextChoices):
        VEG = "VEG", "Vegetarian"
        NONVEG = "NONVEG", "Non-vegetarian"

    student = models.OneToOneField(Student, on_delete=models.CASCADE, related_name="registration")
    is_active = models.BooleanField(default=True)
    diet = models.CharField(max_length=6, choices=Diet.choices, default=Diet.VEG)
    registered_on = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.student} - {'active' if self.is_active else 'inactive'}"


class MealSession(models.Model):
    code = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=20)
    start_time = models.TimeField()
    end_time = models.TimeField()
    order = models.PositiveSmallIntegerField(default=0)

    class Meta:
        ordering = ["order"]

    def __str__(self):
        return self.name


class Menu(models.Model):
    class Category(models.TextChoices):
        VEG = "VEG", "Vegetarian"
        NONVEG = "NONVEG", "Non-vegetarian"

    date = models.DateField()
    session = models.ForeignKey(MealSession, on_delete=models.PROTECT, related_name="menus")
    items = models.TextField(help_text="Comma-separated dishes, e.g. Idli, Sambar, Chutney")
    category = models.CharField(max_length=6, choices=Category.choices, default=Category.VEG)
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["date", "session"], name="uniq_menu_date_session")]
        indexes = [models.Index(fields=["date"])]

    def __str__(self):
        return f"{self.date} {self.session}"


class MealAttendance(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name="attendance")
    session = models.ForeignKey(MealSession, on_delete=models.PROTECT, related_name="attendance")
    date = models.DateField()
    marked_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL)
    marked_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["student", "session", "date"], name="uniq_attendance")]
        indexes = [models.Index(fields=["date", "session"])]

    def __str__(self):
        return f"{self.student} {self.session} {self.date}"


def fee_status(amount, paid):
    if paid >= amount:
        return "PAID"
    return "PARTIAL" if paid > 0 else "PENDING"


class FeeQuerySet(models.QuerySet):
    def with_paid(self):
        return self.annotate(paid_sum=Coalesce(
            Sum("payments__amount"), Value(ZERO),
            output_field=models.DecimalField(max_digits=10, decimal_places=2)))


class MessFee(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name="fees")
    month = models.DateField(help_text="First day of the billing month")
    amount = models.DecimalField(max_digits=8, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    created_at = models.DateTimeField(auto_now_add=True)

    objects = FeeQuerySet.as_manager()

    class Meta:
        ordering = ["-month", "student__full_name"]
        constraints = [models.UniqueConstraint(fields=["student", "month"], name="uniq_fee_student_month")]

    @property
    def paid(self):
        value = getattr(self, "paid_sum", None)
        if value is None:
            value = self.payments.aggregate(t=Sum("amount"))["t"] or ZERO
        return value

    @property
    def balance(self):
        return self.amount - self.paid

    @property
    def status(self):
        return fee_status(self.amount, self.paid)

    def __str__(self):
        return f"{self.student} {self.month:%b %Y}"


class Payment(models.Model):
    """A simulated payment record. No real payment data is ever stored."""
    class Method(models.TextChoices):
        CASH = "CASH", "Cash"
        UPI = "UPI", "UPI"
        CARD = "CARD", "Card"

    fee = models.ForeignKey(MessFee, on_delete=models.CASCADE, related_name="payments")
    amount = models.DecimalField(max_digits=8, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    paid_on = models.DateField()
    reference = models.CharField(max_length=40, unique=True,
                                 validators=[RegexValidator(r"^[A-Za-z0-9-]+$", "Letters, digits and hyphens only.")])
    method = models.CharField(max_length=4, choices=Method.choices, default=Method.CASH)
    recorded_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-paid_on", "-id"]

    def __str__(self):
        return f"{self.reference} {self.amount}"


class Complaint(models.Model):
    class Category(models.TextChoices):
        FOOD = "FOOD", "Food quality"
        HYGIENE = "HYGIENE", "Hygiene"
        MENU = "MENU", "Menu"
        OTHER = "OTHER", "Other"

    class Priority(models.TextChoices):
        LOW = "LOW", "Low"
        MEDIUM = "MEDIUM", "Medium"
        HIGH = "HIGH", "High"

    class Status(models.TextChoices):
        OPEN = "OPEN", "Open"
        IN_PROGRESS = "IN_PROGRESS", "In Progress"
        RESOLVED = "RESOLVED", "Resolved"

    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name="complaints")
    category = models.CharField(max_length=10, choices=Category.choices)
    priority = models.CharField(max_length=6, choices=Priority.choices, default=Priority.MEDIUM)
    subject = models.CharField(max_length=120)
    description = models.TextField()
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.OPEN)
    response = models.TextField(blank=True)
    responded_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["status"])]

    def __str__(self):
        return self.subject


class FoodWasteRecord(models.Model):
    """Meals prepared / served / left over for one session. Wastage % is an estimate."""
    date = models.DateField()
    session = models.ForeignKey(MealSession, on_delete=models.PROTECT, related_name="waste_records")
    prepared = models.PositiveIntegerField(help_text="Meals prepared")
    served = models.PositiveIntegerField(help_text="Meals served")
    leftover = models.PositiveIntegerField(help_text="Meals left over (not eaten)")
    notes = models.CharField(max_length=200, blank=True)
    recorded_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-date", "session__order"]
        constraints = [models.UniqueConstraint(fields=["date", "session"], name="uniq_waste_date_session")]

    def clean(self):
        if self.prepared is not None and self.served is not None and self.served > self.prepared:
            raise ValidationError("Meals served cannot be more than meals prepared.")
        if self.prepared is not None and self.leftover is not None and self.leftover > self.prepared:
            raise ValidationError("Leftover meals cannot be more than meals prepared.")

    @property
    def wastage_pct(self):
        return round(self.leftover * 100 / self.prepared, 1) if self.prepared else 0.0

    def __str__(self):
        return f"{self.date} {self.session}"


class PlannedAbsence(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name="absences")
    date = models.DateField()
    session = models.ForeignKey(MealSession, on_delete=models.CASCADE)
    reason = models.CharField(max_length=120, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["date", "session__order"]
        constraints = [models.UniqueConstraint(fields=["student", "date", "session"], name="uniq_absence")]
        indexes = [models.Index(fields=["date", "session"])]


class MessExpense(models.Model):
    class Category(models.TextChoices):
        GROCERY = "GROCERY", "Groceries"
        PRODUCE = "PRODUCE", "Vegetables & fruit"
        DAIRY = "DAIRY", "Dairy & eggs"
        GAS = "GAS", "Gas & fuel"
        STAFF = "STAFF", "Staff wages"
        MAINT = "MAINT", "Maintenance"
        OTHER = "OTHER", "Other"

    date = models.DateField()
    category = models.CharField(max_length=8, choices=Category.choices)
    description = models.CharField(max_length=150)
    amount = models.DecimalField(max_digits=9, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    recorded_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL)

    class Meta:
        ordering = ["-date", "-id"]


class AuditLog(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL)
    action = models.CharField(max_length=40)
    target = models.CharField(max_length=200)
    detail = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["-created_at", "-id"]

    def __str__(self):
        return f"{self.action}: {self.target}"


def fee_balance(student=None):
    """Total outstanding fee balance (billed minus paid), optionally for one student."""
    fees, pays = MessFee.objects.all(), Payment.objects.all()
    if student is not None:
        fees, pays = fees.filter(student=student), pays.filter(fee__student=student)
    billed = fees.aggregate(t=Sum("amount"))["t"] or ZERO
    paid = pays.aggregate(t=Sum("amount"))["t"] or ZERO
    return billed - paid
