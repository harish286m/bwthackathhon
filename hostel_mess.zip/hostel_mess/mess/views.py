"""Views for all three roles. Every view is protected by role_required."""
import csv
import math
import secrets
from datetime import date, datetime, timedelta
from decimal import Decimal

from django.contrib import messages
from django.contrib.auth import get_user_model
from django.core.exceptions import PermissionDenied
from django.core.paginator import Paginator
from django.db import transaction
from django.db.models import Count, ProtectedError, Q, Sum
from django.http import Http404, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_POST

from . import forms as f
from .models import (AuditLog, Complaint, FoodWasteRecord, HostelRoom, MealAttendance, MealSession, Menu,
                     MessExpense, MessFee, MessRegistration, Payment, PlannedAbsence, Profile, Role, Student,
                     ZERO, fee_balance, fee_status)
from .permissions import ANY_ROLE, get_role, role_required

User = get_user_model()
ADMIN, STAFF, STUDENT = Role.ADMIN, Role.STAFF, Role.STUDENT


# ---------------------------------------------------------------- helpers
def today():
    return timezone.localdate()


def parse_date(value, default=None):
    try:
        return date.fromisoformat(value)
    except (TypeError, ValueError):
        return default


def parse_month(value):
    try:
        return datetime.strptime(value, "%Y-%m").date()
    except (TypeError, ValueError):
        return today().replace(day=1)


def add_months(d, n):
    year, month = divmod(d.year * 12 + d.month - 1 + n, 12)
    return date(year, month + 1, 1)


def pct(n, total):
    return int(round(n * 100 / total)) if total else 0


def log(user, action, target, detail=""):
    AuditLog.objects.create(user=user, action=action, target=str(target)[:200], detail=detail)


def chart(kind, labels, datasets, stacked=False):
    """Config consumed by static/js/app.js (rendered with Chart.js)."""
    return {"type": kind, "labels": labels, "datasets": datasets, "stacked": stacked}


def safe_cell(value):
    # Stops spreadsheet formula injection in exported CSV files.
    if isinstance(value, str) and value[:1] in ("=", "+", "-", "@"):
        return "'" + value
    return value


def csv_response(filename, header, rows):
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = f'attachment; filename="{filename}"'
    writer = csv.writer(response)
    writer.writerow(header)
    for row in rows:
        writer.writerow([safe_cell(c) for c in row])
    return response


def registered_count():
    return MessRegistration.objects.filter(is_active=True).count()


def attendance_by_session(day):
    rows = MealAttendance.objects.filter(date=day).values("session_id").annotate(n=Count("id"))
    return {r["session_id"]: r["n"] for r in rows}


def menu_for_day(day):
    menus = {m.session_id: m for m in Menu.objects.filter(date=day)}
    return [(s, menus.get(s.id)) for s in MealSession.objects.all()]


def demand_estimate(day, session):
    """Estimated meals needed: recent attendance rate x students not planning to be absent (+5% buffer)."""
    reg = registered_count()
    recent = (MealAttendance.objects.filter(session=session, date__lt=day, date__gte=day - timedelta(days=7))
              .values("date").annotate(n=Count("id")))
    counts = [r["n"] for r in recent]
    avg = sum(counts) / len(counts) if counts else float(reg)
    absences = PlannedAbsence.objects.filter(date=day, session=session,
                                             student__registration__is_active=True).count()
    rate = avg / reg if reg else 0
    expected = max(0, round(rate * (reg - absences)))
    return {"registered": reg, "absences": absences, "average": round(avg, 1), "has_history": bool(counts),
            "expected": expected, "recommended": math.ceil(expected * 1.05)}


def get_student(request):
    student = Student.objects.filter(user=request.user).select_related("room").first()
    if not student:
        raise PermissionDenied
    return student


# ---------------------------------------------------------------- entry
@role_required(*ANY_ROLE)
def home(request):
    target = {ADMIN: "admin_dashboard", STAFF: "staff_dashboard", STUDENT: "student_dashboard"}
    return redirect(target[get_role(request.user)])


# ---------------------------------------------------------------- admin dashboard
@role_required(ADMIN)
def admin_dashboard(request):
    d = today()
    sessions = list(MealSession.objects.all())
    counts = attendance_by_session(d)
    reg = registered_count()
    overview = [{"session": s, "count": counts.get(s.id, 0), "pct": pct(counts.get(s.id, 0), reg)} for s in sessions]
    days = [d - timedelta(days=i) for i in range(6, -1, -1)]
    grid = {(r["date"], r["session_id"]): r["n"] for r in
            MealAttendance.objects.filter(date__gte=days[0], date__lte=d).values("date", "session_id").annotate(n=Count("id"))}
    weekly = chart("bar", [x.strftime("%a %d") for x in days],
                   [{"label": s.name, "data": [grid.get((x, s.id), 0) for x in days]} for s in sessions], stacked=True)
    agg = FoodWasteRecord.objects.filter(date__gt=d - timedelta(days=7)).aggregate(p=Sum("prepared"), l=Sum("leftover"))
    waste = {"pct": round(agg["l"] * 100 / agg["p"], 1) if agg["p"] else None, "leftover": agg["l"] or 0,
             "prepared": agg["p"] or 0}
    ctx = {
        "stats": {"students": Student.objects.count(), "today": sum(counts.values()), "registered": reg,
                  "pending": fee_balance(),
                  "complaints": Complaint.objects.exclude(status=Complaint.Status.RESOLVED).count()},
        "overview": overview, "weekly": weekly, "waste": waste, "today_menu": menu_for_day(d), "date": d,
        "recent_complaints": Complaint.objects.select_related("student")[:5],
    }
    return render(request, "dashboard_admin.html", ctx)


# ---------------------------------------------------------------- students & rooms
@role_required(ADMIN)
def students(request):
    qs = Student.objects.select_related("room", "registration")
    q = request.GET.get("q", "").strip()
    if q:
        qs = qs.filter(Q(full_name__icontains=q) | Q(student_id__icontains=q) | Q(room__number__icontains=q))
    dept, year, reg = (request.GET.get(k, "") for k in ("department", "year", "registered"))
    if dept:
        qs = qs.filter(department=dept)
    if year.isdigit():
        qs = qs.filter(year=int(year))
    if reg in ("yes", "no"):
        qs = qs.filter(registration__is_active=(reg == "yes"))
    params = request.GET.copy()
    params.pop("page", None)
    page = Paginator(qs, 10).get_page(request.GET.get("page"))
    return render(request, "students.html", {
        "page_obj": page, "qs": params.urlencode(), "q": q, "dept": dept, "year": year, "reg": reg,
        "departments": Student.Department.choices, "years": range(1, 5)})


def _create_student_login(student):
    username = student.student_id.lower()
    if User.objects.filter(username=username).exists():
        return None
    password = secrets.token_urlsafe(9)
    first, _, last = student.full_name.partition(" ")
    user = User.objects.create_user(username=username, password=password, first_name=first[:30], last_name=last[:150])
    Profile.objects.create(user=user, role=Role.STUDENT, phone=student.contact)
    student.user = user
    student.save(update_fields=["user"])
    return username, password


@role_required(ADMIN)
def student_form(request, pk=None):
    student = get_object_or_404(Student, pk=pk) if pk else None
    form = f.StudentForm(request.POST or None, instance=student)
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            saved = form.save()
            login = None if student else _create_student_login(saved)
            log(request.user, "STUDENT_UPDATE" if student else "STUDENT_CREATE", saved, f"room {saved.room}")
        messages.success(request, f"Saved {saved.full_name}.")
        if login:
            messages.warning(request, f"Login created. Username: {login[0]}  Temporary password: {login[1]} "
                                      "(shown once - ask the student to change it).")
        return redirect("students")
    return render(request, "form_page.html", {"form": form, "back": reverse("students"),
                                              "title": "Edit student" if student else "Add student"})


@role_required(ADMIN)
@require_POST
def student_delete(request, pk):
    student = get_object_or_404(Student, pk=pk)
    name, user = student.full_name, student.user
    student.delete()
    if user:
        user.delete()
    log(request.user, "STUDENT_DELETE", name)
    messages.success(request, f"Removed {name} and all linked records.")
    return redirect("students")


@role_required(ADMIN)
def rooms(request):
    form = f.RoomForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        room = form.save()
        log(request.user, "ROOM_CREATE", room)
        messages.success(request, f"Room {room} added.")
        return redirect("rooms")
    room_list = HostelRoom.objects.annotate(n=Count("students"))
    return render(request, "rooms.html", {"form": form, "rooms": room_list})


@role_required(ADMIN)
@require_POST
def room_delete(request, pk):
    room = get_object_or_404(HostelRoom, pk=pk)
    try:
        room.delete()
        log(request.user, "ROOM_DELETE", room)
        messages.success(request, f"Room {room} removed.")
    except ProtectedError:
        messages.error(request, f"Room {room} still has students. Move them first.")
    return redirect("rooms")


# ---------------------------------------------------------------- menu
@role_required(*ANY_ROLE)
def menu_week(request):
    d = parse_date(request.GET.get("week"), today())
    monday = d - timedelta(days=d.weekday())
    days = [monday + timedelta(days=i) for i in range(7)]
    menus = {(m.date, m.session_id): m for m in Menu.objects.filter(date__range=(days[0], days[-1]))}
    rows = [(s, [(day, menus.get((day, s.id))) for day in days]) for s in MealSession.objects.all()]
    return render(request, "menu.html", {
        "days": days, "rows": rows, "today": today(), "can_edit": get_role(request.user) == ADMIN,
        "prev": monday - timedelta(days=7), "next": monday + timedelta(days=7)})


@role_required(ADMIN)
def menu_edit(request, day, session_id):
    d = parse_date(day)
    if not d:
        raise Http404
    session = get_object_or_404(MealSession, pk=session_id)
    menu = Menu.objects.filter(date=d, session=session).first()
    form = f.MenuForm(request.POST or None, instance=menu)
    if request.method == "POST" and form.is_valid():
        m = form.save(commit=False)
        m.date, m.session, m.updated_by = d, session, request.user
        m.save()
        log(request.user, "MENU_UPDATE", f"{session} {d}", m.items)
        messages.success(request, f"{session} menu for {d:%d %b} saved.")
        return redirect(f"{reverse('menu')}?week={d}")
    return render(request, "form_page.html", {
        "form": form, "title": f"{session} menu - {d:%A, %d %b %Y}",
        "back": f"{reverse('menu')}?week={d}"})


# ---------------------------------------------------------------- attendance
@role_required(ADMIN, STAFF)
def attendance_mark(request):
    sessions = list(MealSession.objects.all())
    src = request.POST if request.method == "POST" else request.GET
    d = parse_date(src.get("date"), today())
    session = next((s for s in sessions if str(s.id) == src.get("session")), sessions[0])
    roster = Student.objects.filter(registration__is_active=True).select_related("room").order_by("full_name")
    existing = set(MealAttendance.objects.filter(date=d, session=session).values_list("student_id", flat=True))
    if request.method == "POST":
        if d > today():
            messages.error(request, "You cannot mark attendance for a future date.")
            return redirect(request.get_full_path())
        valid = set(roster.values_list("id", flat=True))
        selected = {int(x) for x in request.POST.getlist("present") if x.isdigit()} & valid
        to_add, to_remove = selected - existing, existing - selected
        reason = request.POST.get("reason", "").strip()[:150]
        with transaction.atomic():
            for sid in to_add:
                MealAttendance.objects.get_or_create(student_id=sid, session=session, date=d,
                                                     defaults={"marked_by": request.user})
            names = {s.id: s for s in Student.objects.filter(id__in=to_remove)}
            if to_remove:
                MealAttendance.objects.filter(session=session, date=d, student_id__in=to_remove).delete()
            if to_add:
                log(request.user, "ATTENDANCE_CORRECTION" if existing else "ATTENDANCE_MARK", f"{session} {d}",
                    f"added {len(to_add)} student(s). {reason}")
            for sid in to_remove:
                log(request.user, "ATTENDANCE_CORRECTION", f"{session} {d}",
                    f"removed {names[sid].full_name} ({names[sid].student_id}). {reason}")
        messages.success(request, f"{session} attendance for {d:%d %b} saved: {len(selected)} present.")
        return redirect(f"{reverse('attendance_mark')}?date={d}&session={session.id}")
    absent = set(PlannedAbsence.objects.filter(date=d, session=session).values_list("student_id", flat=True))
    return render(request, "attendance_mark.html", {
        "sessions": sessions, "session": session, "date": d, "roster": roster, "present": existing,
        "absent": absent, "max_date": today()})


def _student_rows(month, sessions):
    end = add_months(month, 1)
    grid = {(r["student_id"], r["session_id"]): r["n"] for r in
            MealAttendance.objects.filter(date__gte=month, date__lt=end).values("student_id", "session_id")
            .annotate(n=Count("id"))}
    rows = []
    for s in Student.objects.filter(registration__isnull=False).order_by("full_name"):
        counts = [grid.get((s.id, x.id), 0) for x in sessions]
        rows.append((s, counts, sum(counts)))
    return rows


@role_required(ADMIN)
def attendance_report(request):
    month = parse_month(request.GET.get("month"))
    end = add_months(month, 1)
    sessions = list(MealSession.objects.all())
    grid = {(r["date"], r["session_id"]): r["n"] for r in
            MealAttendance.objects.filter(date__gte=month, date__lt=end).values("date", "session_id")
            .annotate(n=Count("id"))}
    days = sorted({k[0] for k in grid})
    daily = [{"date": d, "counts": [grid.get((d, s.id), 0) for s in sessions],
              "total": sum(grid.get((d, s.id), 0) for s in sessions)} for d in days]
    total = sum(r["total"] for r in daily)
    line = chart("line", [d.strftime("%d %b") for d in days], [{"label": "Meals attended", "data": [r["total"] for r in daily]}])
    return render(request, "attendance_report.html", {
        "month": month, "sessions": sessions, "daily": daily, "total": total, "chart": line,
        "avg_per_day": round(total / len(days), 1) if days else 0, "students": _student_rows(month, sessions)})


# ---------------------------------------------------------------- fees & expenses
@role_required(ADMIN)
def fees(request):
    month = parse_month(request.GET.get("month"))
    gen = f.FeeGenerateForm(request.POST or None, initial={"month": month.strftime("%Y-%m"), "amount": 3000})
    if request.method == "POST" and gen.is_valid():
        m, amount = gen.cleaned_data["month"], gen.cleaned_data["amount"]
        created = sum(MessFee.objects.get_or_create(student=s, month=m, defaults={"amount": amount})[1]
                      for s in Student.objects.filter(registration__is_active=True))
        log(request.user, "FEES_GENERATED", f"{m:%b %Y}", f"{created} new fee record(s) of Rs. {amount}")
        messages.success(request, f"{created} fee record(s) created for {m:%B %Y} (existing ones were left unchanged).")
        return redirect(f"{reverse('fees')}?month={m:%Y-%m}")
    rows = list(MessFee.objects.filter(month=month).select_related("student__room").with_paid())
    q = request.GET.get("q", "").strip().lower()
    status = request.GET.get("status", "")
    if q:
        rows = [r for r in rows if q in r.student.full_name.lower() or q in r.student.student_id.lower()]
    if status in ("PAID", "PARTIAL", "PENDING"):
        rows = [r for r in rows if r.status == status]
    billed = sum((r.amount for r in rows), ZERO)
    collected = sum((r.paid for r in rows), ZERO)
    return render(request, "fees.html", {
        "gen": gen, "rows": rows, "month": month, "q": q, "status": status, "billed": billed,
        "collected": collected, "outstanding": billed - collected,
        "prev": add_months(month, -1), "next": add_months(month, 1)})


@role_required(ADMIN)
def fee_pay(request, pk):
    fee = get_object_or_404(MessFee.objects.select_related("student").with_paid(), pk=pk)
    form = f.PaymentForm(request.POST or None, fee=fee)
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            payment = form.save(commit=False)
            payment.fee, payment.recorded_by = fee, request.user
            payment.save()
            log(request.user, "PAYMENT_RECORDED", f"{fee.student} {fee.month:%b %Y}",
                f"Rs. {payment.amount} ref {payment.reference} (simulated)")
        messages.success(request, f"Recorded Rs. {payment.amount} for {fee.student.full_name}.")
        return redirect(f"{reverse('fees')}?month={fee.month:%Y-%m}")
    return render(request, "fee_pay.html", {"fee": fee, "form": form, "payments": fee.payments.all()})


@role_required(ADMIN)
def expenses(request):
    month = parse_month(request.GET.get("month"))
    form = f.ExpenseForm(request.POST or None, initial={"date": today()})
    if request.method == "POST" and form.is_valid():
        e = form.save(commit=False)
        e.recorded_by = request.user
        e.save()
        log(request.user, "EXPENSE_ADDED", e.description, f"Rs. {e.amount}")
        messages.success(request, "Expense recorded.")
        return redirect(f"{reverse('expenses')}?month={e.date:%Y-%m}")
    rows = MessExpense.objects.filter(date__gte=month, date__lt=add_months(month, 1))
    by_cat = {}
    for r in rows:
        by_cat[r.get_category_display()] = by_cat.get(r.get_category_display(), ZERO) + r.amount
    collected = Payment.objects.filter(paid_on__gte=month, paid_on__lt=add_months(month, 1)).aggregate(t=Sum("amount"))["t"] or ZERO
    total = sum(by_cat.values(), ZERO)
    return render(request, "expenses.html", {
        "form": form, "rows": rows, "month": month, "total": total, "by_cat": sorted(by_cat.items()),
        "collected": collected, "net": collected - total,
        "prev": add_months(month, -1), "next": add_months(month, 1)})


# ---------------------------------------------------------------- complaints (admin)
@role_required(ADMIN)
def complaints(request):
    qs = Complaint.objects.select_related("student")
    status, category = request.GET.get("status", ""), request.GET.get("category", "")
    if status:
        qs = qs.filter(status=status)
    if category:
        qs = qs.filter(category=category)
    params = request.GET.copy()
    params.pop("page", None)
    page = Paginator(qs, 10).get_page(request.GET.get("page"))
    return render(request, "complaints.html", {
        "page_obj": page, "qs": params.urlencode(), "status": status, "category": category,
        "statuses": Complaint.Status.choices, "categories": Complaint.Category.choices})


@role_required(ADMIN)
def complaint_detail(request, pk):
    complaint = get_object_or_404(Complaint.objects.select_related("student"), pk=pk)
    form = f.ComplaintResponseForm(request.POST or None, instance=complaint)
    if request.method == "POST" and form.is_valid():
        c = form.save(commit=False)
        c.responded_by = request.user
        c.save()
        log(request.user, "COMPLAINT_UPDATE", f"#{c.pk} {c.subject}", f"status {c.get_status_display()}")
        messages.success(request, "Complaint updated.")
        return redirect("complaints")
    return render(request, "complaint_detail.html", {"complaint": complaint, "form": form})


# ---------------------------------------------------------------- food waste
@role_required(ADMIN, STAFF)
def waste(request):
    sessions = list(MealSession.objects.all())
    src = request.POST if request.method == "POST" else request.GET
    d = parse_date(src.get("date"), today())
    session = next((s for s in sessions if str(s.id) == src.get("session")), sessions[0])
    instance = FoodWasteRecord.objects.filter(date=d, session=session).first()
    attended = MealAttendance.objects.filter(date=d, session=session).count()
    if request.method == "POST":
        form = f.FoodWasteForm(request.POST, instance=instance)
        if form.is_valid():
            rec = form.save(commit=False)
            rec.recorded_by = request.user
            rec.save()
            log(request.user, "WASTE_RECORDED", f"{rec.session} {rec.date}",
                f"prepared {rec.prepared}, served {rec.served}, leftover {rec.leftover}")
            messages.success(request, f"Saved {rec.session} record for {rec.date:%d %b}: {rec.wastage_pct}% estimated wastage.")
            return redirect(f"{reverse('waste')}?date={rec.date}&session={rec.session_id}")
    else:
        form = f.FoodWasteForm(instance=instance, initial={"date": d, "session": session, "served": attended or None})
    d0 = today() - timedelta(days=13)
    recs = list(FoodWasteRecord.objects.filter(date__gte=d0).select_related("session"))
    demand = {(r["date"], r["session_id"]): r["n"] for r in
              MealAttendance.objects.filter(date__gte=d0).values("date", "session_id").annotate(n=Count("id"))}
    days = [d0 + timedelta(days=i) for i in range(14)]
    tot = {x: [0, 0, 0] for x in days}
    for r in recs:
        tot[r.date][0] += r.prepared
        tot[r.date][1] += r.leftover
        tot[r.date][2] += demand.get((r.date, r.session_id), 0)
    labels = [x.strftime("%d %b") for x in days]
    trend = chart("line", labels, [{"label": "Wastage % (estimated)",
                                    "data": [round(tot[x][1] * 100 / tot[x][0], 1) if tot[x][0] else None for x in days]}])
    compare = chart("bar", labels, [{"label": "Meals prepared", "data": [tot[x][0] for x in days]},
                                    {"label": "Meals attended (demand)", "data": [tot[x][2] for x in days]}])
    table = [(r, demand.get((r.date, r.session_id), 0)) for r in recs[:20]]
    return render(request, "waste.html", {
        "form": form, "sessions": sessions, "session": session, "date": d, "estimate": demand_estimate(d, session),
        "trend": trend, "compare": compare, "table": table, "existing": instance, "max_date": today()})


# ---------------------------------------------------------------- reports
@role_required(ADMIN)
def reports(request):
    month = parse_month(request.GET.get("month"))
    end = add_months(month, 1)
    att = {r["date"]: r["n"] for r in MealAttendance.objects.filter(date__gte=month, date__lt=end)
           .values("date").annotate(n=Count("id"))}
    days = sorted(att)
    months = [add_months(month, -i) for i in range(5, -1, -1)]
    billed, collected = {m: ZERO for m in months}, {m: ZERO for m in months}
    for fee in MessFee.objects.filter(month__gte=months[0], month__lte=months[-1]).with_paid():
        billed[fee.month] += fee.amount
        collected[fee.month] += fee.paid
    waste_days = {}
    for r in FoodWasteRecord.objects.filter(date__gte=month, date__lt=end):
        p, l = waste_days.get(r.date, (0, 0))
        waste_days[r.date] = (p + r.prepared, l + r.leftover)
    wdays = sorted(waste_days)
    comp = Complaint.objects.filter(created_at__date__gte=month, created_at__date__lt=end)
    by_cat = {c.label: comp.filter(category=c.value).count() for c in Complaint.Category}
    by_status = {c.label: Complaint.objects.filter(status=c.value).count() for c in Complaint.Status}
    month_labels = [m.strftime("%b %y") for m in months]
    wp = sum(p for p, _ in waste_days.values())
    wl = sum(l for _, l in waste_days.values())
    charts = {
        "attendance": chart("line", [d.strftime("%d %b") for d in days], [{"label": "Meals attended", "data": [att[d] for d in days]}]),
        "fees": chart("bar", month_labels, [{"label": "Billed (Rs.)", "data": [float(billed[m]) for m in months]},
                                            {"label": "Collected (Rs.)", "data": [float(collected[m]) for m in months]}]),
        "outstanding": chart("bar", month_labels, [{"label": "Outstanding (Rs.)", "data": [float(billed[m] - collected[m]) for m in months]}]),
        "waste": chart("line", [d.strftime("%d %b") for d in wdays], [{"label": "Wastage % (estimated)", "data": [round(waste_days[d][1] * 100 / waste_days[d][0], 1) for d in wdays]}]),
        "categories": chart("doughnut", list(by_cat), [{"label": "Complaints", "data": list(by_cat.values())}]),
        "status": chart("doughnut", list(by_status), [{"label": "Complaints", "data": list(by_status.values())}]),
    }
    summary = {"attended": sum(att.values()), "billed": billed[month], "collected": collected[month],
               "outstanding": billed[month] - collected[month], "waste": round(wl * 100 / wp, 1) if wp else None,
               "complaints": comp.count()}
    return render(request, "reports.html", {"month": month, "charts": charts, "summary": summary,
                                            "prev": add_months(month, -1), "next": add_months(month, 1)})


@role_required(ADMIN)
def export_csv(request, kind):
    month = parse_month(request.GET.get("month"))
    end = add_months(month, 1)
    tag = f"{month:%Y-%m}"
    if kind == "attendance":
        sessions = list(MealSession.objects.all())
        rows = [[s.student_id, s.full_name, *c, t] for s, c, t in _student_rows(month, sessions)]
        return csv_response(f"attendance-{tag}.csv", ["Student ID", "Name", *[x.name for x in sessions], "Total meals"], rows)
    if kind == "fees":
        fees_qs = MessFee.objects.filter(month=month).select_related("student").with_paid()
        rows = [[x.student.student_id, x.student.full_name, x.amount, x.paid, x.balance, x.status] for x in fees_qs]
        return csv_response(f"fees-{tag}.csv", ["Student ID", "Name", "Billed", "Paid", "Balance", "Status"], rows)
    if kind == "outstanding":
        rows = [[x.student.student_id, x.student.full_name, f"{x.month:%Y-%m}", x.balance] for x in
                MessFee.objects.select_related("student").with_paid() if x.balance > 0]
        return csv_response("outstanding-fees.csv", ["Student ID", "Name", "Month", "Balance"], rows)
    if kind == "waste":
        rows = [[r.date, r.session.name, r.prepared, r.served, r.leftover, r.wastage_pct] for r in
                FoodWasteRecord.objects.filter(date__gte=month, date__lt=end).select_related("session")]
        return csv_response(f"food-waste-{tag}.csv", ["Date", "Session", "Prepared", "Served", "Leftover", "Wastage % (estimated)"], rows)
    if kind == "complaints":
        rows = [[c.pk, c.student.student_id, c.get_category_display(), c.get_priority_display(),
                 c.get_status_display(), c.subject, c.created_at.date()] for c in
                Complaint.objects.filter(created_at__date__gte=month, created_at__date__lt=end).select_related("student")]
        return csv_response(f"complaints-{tag}.csv", ["ID", "Student ID", "Category", "Priority", "Status", "Subject", "Date"], rows)
    raise Http404


@role_required(ADMIN)
def audit(request):
    return render(request, "audit.html", {"logs": AuditLog.objects.select_related("user")[:100]})


# ---------------------------------------------------------------- mess staff
@role_required(STAFF)
def staff_dashboard(request):
    d = today()
    counts = attendance_by_session(d)
    absences = {r["session_id"]: r["n"] for r in PlannedAbsence.objects.filter(date=d).values("session_id").annotate(n=Count("id"))}
    waste_done = set(FoodWasteRecord.objects.filter(date=d).values_list("session_id", flat=True))
    rows = [{"session": s, "menu": m, "count": counts.get(s.id, 0), "absences": absences.get(s.id, 0),
             "waste_done": s.id in waste_done} for s, m in menu_for_day(d)]
    return render(request, "dashboard_staff.html", {"rows": rows, "date": d, "registered": registered_count(),
                                                    "now": timezone.localtime().time()})


# ---------------------------------------------------------------- student
@role_required(STUDENT)
def student_dashboard(request):
    student = get_student(request)
    d = today()
    month_start = d.replace(day=1)
    ctx = {
        "student": student, "date": d, "today_menu": menu_for_day(d),
        "meals_month": MealAttendance.objects.filter(student=student, date__gte=month_start).count(),
        "balance": fee_balance(student),
        "open_complaints": student.complaints.exclude(status=Complaint.Status.RESOLVED).count(),
        "absences": student.absences.filter(date__gte=d).select_related("session")[:5],
    }
    return render(request, "dashboard_student.html", ctx)


@role_required(STUDENT)
def my_attendance(request):
    student = get_student(request)
    month = parse_month(request.GET.get("month"))
    sessions = list(MealSession.objects.all())
    got = set(MealAttendance.objects.filter(student=student, date__gte=month, date__lt=add_months(month, 1))
              .values_list("date", "session_id"))
    last = min(add_months(month, 1) - timedelta(days=1), today())
    days = [last - timedelta(days=i) for i in range((last - month).days + 1)] if last >= month else []
    rows = [(d, [(d, s.id) in got for s in sessions]) for d in days]
    return render(request, "my_attendance.html", {
        "sessions": sessions, "rows": rows, "month": month, "total": len(got),
        "prev": add_months(month, -1), "next": add_months(month, 1)})


@role_required(STUDENT)
def my_fees(request):
    student = get_student(request)
    fee_rows = list(student.fees.with_paid())
    payments = Payment.objects.filter(fee__student=student).select_related("fee")
    return render(request, "my_fees.html", {"fees": fee_rows, "payments": payments, "balance": fee_balance(student)})


@role_required(STUDENT)
def my_complaints(request):
    student = get_student(request)
    return render(request, "my_complaints.html", {"complaints": student.complaints.all()})


@role_required(STUDENT)
def complaint_new(request):
    student = get_student(request)
    form = f.ComplaintForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        c = form.save(commit=False)
        c.student = student
        c.save()
        messages.success(request, "Complaint submitted. You can track its status here.")
        return redirect("my_complaints")
    return render(request, "form_page.html", {"form": form, "title": "New complaint or suggestion",
                                              "back": reverse("my_complaints"), "submit": "Submit"})


@role_required(STUDENT)
def my_absences(request):
    student = get_student(request)
    form = f.AbsenceForm(request.POST or None, initial={"date": today() + timedelta(days=1)})
    if request.method == "POST" and form.is_valid():
        new = 0
        for s in form.cleaned_data["sessions"]:
            _, created = PlannedAbsence.objects.get_or_create(
                student=student, date=form.cleaned_data["date"], session=s,
                defaults={"reason": form.cleaned_data["reason"]})
            new += created
        messages.success(request, f"{new} planned absence(s) saved. Thank you - this helps cut food waste.")
        return redirect("my_absences")
    upcoming = student.absences.filter(date__gte=today()).select_related("session")
    return render(request, "my_absences.html", {"form": form, "upcoming": upcoming})


@role_required(STUDENT)
@require_POST
def absence_delete(request, pk):
    student = get_student(request)
    absence = get_object_or_404(PlannedAbsence, pk=pk, student=student)
    if absence.date < today():
        raise PermissionDenied
    absence.delete()
    messages.success(request, "Planned absence cancelled.")
    return redirect("my_absences")
