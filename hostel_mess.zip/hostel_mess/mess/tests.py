"""Tests: authentication, role permissions, attendance, fee calculations, waste, demo data."""
from datetime import timedelta
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.db import IntegrityError, transaction
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .forms import PaymentForm
from .models import (AuditLog, Complaint, FoodWasteRecord, HostelRoom, MealAttendance, MealSession, MessFee,
                     MessRegistration, Payment, PlannedAbsence, Profile, Role, Student, fee_balance)

User = get_user_model()
PASSWORD = "Test-pass-123"


def make_user(username, role):
    user = User.objects.create_user(username, password=PASSWORD)
    Profile.objects.create(user=user, role=role)
    return user


class Base(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.admin = make_user("warden", Role.ADMIN)
        cls.staff = make_user("cook", Role.STAFF)
        cls.stu_user = make_user("stu1", Role.STUDENT)
        cls.room = HostelRoom.objects.create(number="1", capacity=2)
        cls.student = cls.make_student("S0001", cls.stu_user)
        cls.other = cls.make_student("S0002")
        cls.lunch = MealSession.objects.get(code="LUNCH")
        cls.today = timezone.localdate()

    @classmethod
    def make_student(cls, sid, user=None):
        s = Student.objects.create(user=user, student_id=sid, full_name=f"Student {sid}", department="CSE",
                                   year=1, room=cls.room, contact="9000000000")
        MessRegistration.objects.create(student=s)
        return s

    def login(self, user):
        self.client.force_login(user)


class AuthTests(Base):
    def test_anonymous_is_sent_to_login(self):
        for name in ("home", "admin_dashboard", "student_dashboard", "attendance_mark"):
            response = self.client.get(reverse(name))
            self.assertRedirects(response, f"{reverse('login')}?next={reverse(name)}")

    def test_login_redirects_by_role(self):
        for user, target in ((self.admin, "admin_dashboard"), (self.staff, "staff_dashboard"),
                             (self.stu_user, "student_dashboard")):
            self.client.logout()
            response = self.client.post(reverse("login"), {"username": user.username, "password": PASSWORD}, follow=True)
            self.assertEqual(response.redirect_chain[-1][0], reverse(target))

    def test_wrong_password_is_rejected(self):
        response = self.client.post(reverse("login"), {"username": "warden", "password": "nope"})
        self.assertEqual(response.status_code, 200)
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_logout_requires_post(self):
        self.login(self.admin)
        self.assertEqual(self.client.get(reverse("logout")).status_code, 405)
        self.client.post(reverse("logout"))
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_user_without_role_is_denied(self):
        self.login(User.objects.create_user("norole", password=PASSWORD))
        self.assertEqual(self.client.get(reverse("home")).status_code, 403)


class PermissionTests(Base):
    def test_student_cannot_use_admin_or_staff_pages(self):
        self.login(self.stu_user)
        for name in ("admin_dashboard", "students", "fees", "complaints", "reports", "attendance_mark", "waste", "audit"):
            self.assertEqual(self.client.get(reverse(name)).status_code, 403, name)

    def test_staff_cannot_use_admin_pages(self):
        self.login(self.staff)
        for name in ("admin_dashboard", "students", "fees", "expenses", "reports", "audit"):
            self.assertEqual(self.client.get(reverse(name)).status_code, 403, name)
        self.assertEqual(self.client.get(reverse("attendance_mark")).status_code, 200)
        self.assertEqual(self.client.get(reverse("waste")).status_code, 200)

    def test_admin_cannot_use_student_pages(self):
        self.login(self.admin)
        self.assertEqual(self.client.get(reverse("student_dashboard")).status_code, 403)

    def test_post_actions_are_enforced_on_server(self):
        fee = MessFee.objects.create(student=self.student, month=self.today.replace(day=1), amount=Decimal("3000"))
        data = {"amount": "100", "paid_on": self.today.isoformat(), "method": "CASH", "reference": "R1"}
        for user in (self.stu_user, self.staff):
            self.login(user)
            self.assertEqual(self.client.post(reverse("fee_pay", args=[fee.pk]), data).status_code, 403)
            self.assertEqual(self.client.post(reverse("student_delete", args=[self.other.pk])).status_code, 403)
            self.assertEqual(self.client.post(reverse("menu_edit", args=[self.today.isoformat(), self.lunch.pk]),
                                              {"items": "Rice, Dal", "category": "VEG"}).status_code, 403)
        self.assertEqual(Payment.objects.count(), 0)
        self.assertTrue(Student.objects.filter(pk=self.other.pk).exists())

    def test_student_cannot_cancel_another_students_absence(self):
        absence = PlannedAbsence.objects.create(student=self.other, date=self.today + timedelta(days=1), session=self.lunch)
        self.login(self.stu_user)
        self.assertEqual(self.client.post(reverse("absence_delete", args=[absence.pk])).status_code, 404)

    def test_student_sees_only_own_complaints(self):
        Complaint.objects.create(student=self.other, category="FOOD", subject="Other's secret", description="x" * 20)
        Complaint.objects.create(student=self.student, category="FOOD", subject="Mine", description="y" * 20)
        self.login(self.stu_user)
        body = self.client.get(reverse("my_complaints")).content.decode()
        self.assertIn("Mine", body)
        self.assertNotIn("Other's secret", body)


class AttendanceTests(Base):
    def post(self, ids, day=None, reason=""):
        return self.client.post(reverse("attendance_mark"), {
            "date": (day or self.today).isoformat(), "session": self.lunch.pk, "present": ids, "reason": reason})

    def test_database_blocks_duplicates(self):
        MealAttendance.objects.create(student=self.student, session=self.lunch, date=self.today)
        with self.assertRaises(IntegrityError), transaction.atomic():
            MealAttendance.objects.create(student=self.student, session=self.lunch, date=self.today)

    def test_marking_twice_does_not_duplicate(self):
        self.login(self.staff)
        self.post([self.student.pk])
        self.post([self.student.pk])
        self.assertEqual(MealAttendance.objects.filter(student=self.student).count(), 1)

    def test_correction_removes_record_and_writes_audit_trail(self):
        self.login(self.staff)
        self.post([self.student.pk, self.other.pk])
        self.post([self.student.pk], reason="Marked wrong student")
        self.assertFalse(MealAttendance.objects.filter(student=self.other).exists())
        entry = AuditLog.objects.filter(action="ATTENDANCE_CORRECTION").first()
        self.assertIn(self.other.student_id, entry.detail)
        self.assertIn("Marked wrong student", entry.detail)
        self.assertEqual(entry.user, self.staff)

    def test_future_date_is_rejected(self):
        self.login(self.staff)
        self.post([self.student.pk], day=self.today + timedelta(days=1))
        self.assertEqual(MealAttendance.objects.count(), 0)

    def test_unregistered_student_is_ignored(self):
        MessRegistration.objects.filter(student=self.other).update(is_active=False)
        self.login(self.staff)
        self.post([self.other.pk])
        self.assertEqual(MealAttendance.objects.count(), 0)


class FeeTests(Base):
    def setUp(self):
        self.fee = MessFee.objects.create(student=self.student, month=self.today.replace(day=1), amount=Decimal("3000"))

    def pay(self, amount, ref):
        return Payment.objects.create(fee=self.fee, amount=Decimal(amount), paid_on=self.today, reference=ref)

    def test_status_and_balance_progression(self):
        self.assertEqual((self.fee.status, self.fee.balance), ("PENDING", Decimal("3000")))
        self.pay("1000", "A1")
        self.assertEqual((self.fee.status, self.fee.balance), ("PARTIAL", Decimal("2000")))
        self.pay("2000", "A2")
        self.assertEqual((self.fee.status, self.fee.balance), ("PAID", Decimal("0")))

    def test_annotated_queryset_matches_properties(self):
        self.pay("500", "B1")
        fee = MessFee.objects.with_paid().get(pk=self.fee.pk)
        self.assertEqual((fee.paid, fee.balance), (Decimal("500"), Decimal("2500")))

    def test_total_outstanding_across_fees(self):
        MessFee.objects.create(student=self.other, month=self.today.replace(day=1), amount=Decimal("2000"))
        self.pay("1000", "C1")
        self.assertEqual(fee_balance(), Decimal("4000"))
        self.assertEqual(fee_balance(self.student), Decimal("2000"))

    def test_overpayment_and_zero_are_rejected(self):
        self.pay("2500", "D1")
        for amount in ("600", "0"):
            form = PaymentForm({"amount": amount, "paid_on": self.today, "method": "CASH", "reference": "D2"}, fee=self.fee)
            self.assertFalse(form.is_valid(), amount)
        ok = PaymentForm({"amount": "500", "paid_on": self.today, "method": "CASH", "reference": "D3"}, fee=self.fee)
        self.assertTrue(ok.is_valid(), ok.errors)

    def test_duplicate_reference_is_rejected(self):
        self.pay("100", "DUP")
        form = PaymentForm({"amount": "100", "paid_on": self.today, "method": "UPI", "reference": "DUP"}, fee=self.fee)
        self.assertFalse(form.is_valid())

    def test_one_fee_per_student_per_month(self):
        with self.assertRaises(IntegrityError), transaction.atomic():
            MessFee.objects.create(student=self.student, month=self.fee.month, amount=Decimal("10"))

    def test_generate_fees_is_idempotent_and_view_records_payment(self):
        self.login(self.admin)
        data = {"month": "2026-01", "amount": "2500"}
        self.client.post(reverse("fees"), data)
        self.client.post(reverse("fees"), data)
        self.assertEqual(MessFee.objects.filter(month="2026-01-01").count(), 2)
        self.client.post(reverse("fee_pay", args=[self.fee.pk]), {
            "amount": "1500", "paid_on": self.today.isoformat(), "method": "UPI", "reference": "UPI-1"})
        self.assertEqual(MessFee.objects.with_paid().get(pk=self.fee.pk).balance, Decimal("1500"))
        self.assertTrue(AuditLog.objects.filter(action="PAYMENT_RECORDED").exists())


class WasteTests(Base):
    def test_wastage_percentage(self):
        r = FoodWasteRecord(date=self.today, session=self.lunch, prepared=200, served=170, leftover=30)
        self.assertEqual(r.wastage_pct, 15.0)
        self.assertEqual(FoodWasteRecord(date=self.today, session=self.lunch, prepared=0, served=0, leftover=0).wastage_pct, 0)

    def test_invalid_numbers_rejected_and_record_updates_in_place(self):
        self.login(self.staff)
        url = reverse("waste")
        base = {"date": self.today.isoformat(), "session": self.lunch.pk, "notes": ""}
        bad = self.client.post(url, {**base, "prepared": 50, "served": 60, "leftover": 5})
        self.assertEqual(FoodWasteRecord.objects.count(), 0)
        self.assertContains(bad, "cannot be more than")
        self.client.post(url, {**base, "prepared": 50, "served": 45, "leftover": 5})
        self.client.post(url, {**base, "prepared": 60, "served": 45, "leftover": 15})
        self.assertEqual(FoodWasteRecord.objects.get().prepared, 60)

    def test_planned_absences_lower_the_estimate(self):
        from .views import demand_estimate
        before = demand_estimate(self.today, self.lunch)["expected"]
        PlannedAbsence.objects.create(student=self.student, date=self.today, session=self.lunch)
        after = demand_estimate(self.today, self.lunch)
        self.assertEqual(after["absences"], 1)
        self.assertLess(after["expected"], before)


class DemoDataTests(TestCase):
    def test_seed_is_rerunnable_and_every_page_loads(self):
        call_command("seed_demo", verbosity=0)
        models = (Student, HostelRoom, MealAttendance, MessFee, Payment, Complaint, FoodWasteRecord, PlannedAbsence)
        first = [m.objects.count() for m in models]
        call_command("seed_demo", verbosity=0)
        self.assertEqual(first, [m.objects.count() for m in models])
        self.assertEqual(Student.objects.count(), 30)
        self.assertEqual(HostelRoom.objects.count(), 5)

        fee = MessFee.objects.first()
        pages = {
            "demo_admin": [("admin_dashboard", []), ("students", []), ("student_add", []), ("rooms", []), ("menu", []),
                           ("attendance_mark", []), ("attendance_report", []), ("fees", []), ("fee_pay", [fee.pk]),
                           ("expenses", []), ("complaints", []), ("complaint_detail", [Complaint.objects.first().pk]),
                           ("waste", []), ("reports", []), ("audit", []),
                           ("student_edit", [Student.objects.first().pk]),
                           ("export_csv", ["attendance"]), ("export_csv", ["fees"]), ("export_csv", ["outstanding"]),
                           ("export_csv", ["waste"]), ("export_csv", ["complaints"])],
            "demo_staff": [("staff_dashboard", []), ("menu", []), ("attendance_mark", []), ("waste", [])],
            "demo_student": [("student_dashboard", []), ("menu", []), ("my_attendance", []), ("my_fees", []),
                             ("my_complaints", []), ("complaint_new", []), ("my_absences", [])],
        }
        for username, items in pages.items():
            self.client.force_login(User.objects.get(username=username))
            for name, args in items:
                response = self.client.get(reverse(name, args=args))
                self.assertEqual(response.status_code, 200, f"{username}: {name}")

    def test_student_can_submit_complaint_and_planned_absence(self):
        call_command("seed_demo", verbosity=0)
        self.client.force_login(User.objects.get(username="demo_student"))
        before = Complaint.objects.count()
        self.client.post(reverse("complaint_new"), {"category": "FOOD", "priority": "LOW", "subject": "Test",
                                                    "description": "This is a test complaint."})
        self.assertEqual(Complaint.objects.count(), before + 1)
        day = timezone.localdate() + timedelta(days=5)
        lunch = MealSession.objects.get(code="LUNCH")
        self.client.post(reverse("my_absences"), {"date": day.isoformat(), "sessions": [lunch.pk], "reason": "Trip"})
        self.assertTrue(PlannedAbsence.objects.filter(date=day, session=lunch, student__user__username="demo_student").exists())
        past = self.client.post(reverse("my_absences"), {"date": (timezone.localdate() - timedelta(days=1)).isoformat(),
                                                         "sessions": [lunch.pk]})
        self.assertContains(past, "Choose today or a future date")
