"""Template context: role-based sidebar navigation."""
from .models import Role
from .permissions import get_role

NAV = {
    Role.ADMIN: [
        ("Dashboard", "speedometer2", "admin_dashboard", ["admin_dashboard"]),
        ("Students", "people", "students", ["students", "student_add", "student_edit"]),
        ("Rooms", "door-open", "rooms", ["rooms"]),
        ("Menu", "journal-text", "menu", ["menu", "menu_edit"]),
        ("Mark attendance", "check2-square", "attendance_mark", ["attendance_mark"]),
        ("Attendance report", "bar-chart", "attendance_report", ["attendance_report"]),
        ("Fees", "cash-coin", "fees", ["fees", "fee_pay"]),
        ("Expenses", "receipt", "expenses", ["expenses"]),
        ("Complaints", "chat-left-text", "complaints", ["complaints", "complaint_detail"]),
        ("Food waste", "recycle", "waste", ["waste"]),
        ("Reports", "graph-up", "reports", ["reports"]),
        ("Audit log", "shield-check", "audit", ["audit"]),
    ],
    Role.STAFF: [
        ("Dashboard", "speedometer2", "staff_dashboard", ["staff_dashboard"]),
        ("Menu", "journal-text", "menu", ["menu"]),
        ("Mark attendance", "check2-square", "attendance_mark", ["attendance_mark"]),
        ("Food waste", "recycle", "waste", ["waste"]),
    ],
    Role.STUDENT: [
        ("Dashboard", "speedometer2", "student_dashboard", ["student_dashboard"]),
        ("Weekly menu", "journal-text", "menu", ["menu"]),
        ("My attendance", "calendar-check", "my_attendance", ["my_attendance"]),
        ("My fees", "wallet2", "my_fees", ["my_fees"]),
        ("Complaints", "chat-left-text", "my_complaints", ["my_complaints", "complaint_new"]),
        ("Planned absences", "calendar-x", "my_absences", ["my_absences"]),
    ],
}


def navigation(request):
    role = get_role(request.user)
    items = [{"label": a, "icon": b, "url": c, "names": d} for a, b, c, d in NAV.get(role, [])]
    return {"nav": items, "role": role, "role_label": Role(role).label if role else ""}
