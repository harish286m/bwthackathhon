from django.contrib.auth import views as auth_views
from django.urls import path, reverse_lazy

from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("login/", auth_views.LoginView.as_view(template_name="registration/login.html",
                                                redirect_authenticated_user=True), name="login"),
    path("logout/", auth_views.LogoutView.as_view(), name="logout"),
    path("password/", auth_views.PasswordChangeView.as_view(
        template_name="registration/password_change.html", success_url=reverse_lazy("home")), name="password_change"),

    # shared
    path("menu/", views.menu_week, name="menu"),
    path("attendance/mark/", views.attendance_mark, name="attendance_mark"),
    path("waste/", views.waste, name="waste"),

    # admin / warden
    path("manage/", views.admin_dashboard, name="admin_dashboard"),
    path("manage/students/", views.students, name="students"),
    path("manage/students/add/", views.student_form, name="student_add"),
    path("manage/students/<int:pk>/edit/", views.student_form, name="student_edit"),
    path("manage/students/<int:pk>/delete/", views.student_delete, name="student_delete"),
    path("manage/rooms/", views.rooms, name="rooms"),
    path("manage/rooms/<int:pk>/delete/", views.room_delete, name="room_delete"),
    path("manage/menu/<str:day>/<int:session_id>/", views.menu_edit, name="menu_edit"),
    path("manage/attendance/report/", views.attendance_report, name="attendance_report"),
    path("manage/fees/", views.fees, name="fees"),
    path("manage/fees/<int:pk>/pay/", views.fee_pay, name="fee_pay"),
    path("manage/expenses/", views.expenses, name="expenses"),
    path("manage/complaints/", views.complaints, name="complaints"),
    path("manage/complaints/<int:pk>/", views.complaint_detail, name="complaint_detail"),
    path("manage/reports/", views.reports, name="reports"),
    path("manage/reports/export/<str:kind>/", views.export_csv, name="export_csv"),
    path("manage/audit/", views.audit, name="audit"),

    # mess staff
    path("staff/", views.staff_dashboard, name="staff_dashboard"),

    # student
    path("me/", views.student_dashboard, name="student_dashboard"),
    path("me/attendance/", views.my_attendance, name="my_attendance"),
    path("me/fees/", views.my_fees, name="my_fees"),
    path("me/complaints/", views.my_complaints, name="my_complaints"),
    path("me/complaints/new/", views.complaint_new, name="complaint_new"),
    path("me/absences/", views.my_absences, name="my_absences"),
    path("me/absences/<int:pk>/cancel/", views.absence_delete, name="absence_delete"),
]
