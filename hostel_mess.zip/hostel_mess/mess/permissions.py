"""Server-side role checks. Hiding a link is never the only protection."""
from functools import wraps

from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied

from .models import Role

ANY_ROLE = (Role.ADMIN, Role.STAFF, Role.STUDENT)


def get_role(user):
    if not user.is_authenticated:
        return None
    profile = getattr(user, "profile", None)
    if profile:
        return profile.role
    return Role.ADMIN if user.is_superuser else None


def role_required(*roles):
    """Require login and one of the given roles, otherwise answer 403."""
    def decorator(view):
        @wraps(view)
        @login_required
        def wrapper(request, *args, **kwargs):
            if get_role(request.user) not in roles:
                raise PermissionDenied
            return view(request, *args, **kwargs)
        return wrapper
    return decorator
