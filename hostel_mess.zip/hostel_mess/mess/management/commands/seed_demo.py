"""Populate the database with realistic demo data. Safe to run repeatedly."""
import math
import random
from datetime import timedelta
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password
from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone

from mess.models import (Complaint, FoodWasteRecord, HostelRoom, MealAttendance, MealSession, Menu, MessExpense,
                         MessFee, MessRegistration, Payment, PlannedAbsence, Profile, Role, Student)

User = get_user_model()

NAMES = ["Aarav Reddy", "Ananya Sharma", "Rohit Kumar", "Sneha Patel", "Vikram Singh", "Priya Nair",
         "Karthik Rao", "Meera Iyer", "Arjun Mehta", "Divya Menon", "Rahul Verma", "Pooja Gupta",
         "Sai Teja", "Nikhil Joshi", "Lakshmi Prasad", "Imran Khan", "Harini Krishnan", "Aditya Bansal",
         "Swathi Reddy", "Manoj Yadav", "Neha Kapoor", "Varun Chowdary", "Ishita Das", "Tarun Naidu",
         "Bhavana Rao", "Siddharth Jain", "Anjali Pillai", "Mohit Agarwal", "Kavya Shetty", "Rishi Kulkarni"]
DEPTS = ["CSE", "IT", "ECE", "MECH", "CIVIL"]

# Weekly rotation: weekday (0=Mon) -> (items, category) for Breakfast, Lunch, Snacks, Dinner
MENU = {
    0: [("Idli, Sambar, Coconut chutney", "VEG"), ("Rice, Dal tadka, Aloo gobi, Curd", "VEG"), ("Samosa, Tea", "VEG"), ("Chapati, Paneer butter masala, Jeera rice", "VEG")],
    1: [("Poori, Aloo masala", "VEG"), ("Rice, Sambar, Beans poriyal, Papad", "VEG"), ("Veg puff, Tea", "VEG"), ("Chicken curry, Rice, Chapati", "NONVEG")],
    2: [("Upma, Peanut chutney", "VEG"), ("Veg biryani, Raita", "VEG"), ("Banana chips, Tea", "VEG"), ("Chapati, Mixed veg kurma, Rice", "VEG")],
    3: [("Dosa, Sambar, Tomato chutney", "VEG"), ("Rice, Rasam, Cabbage fry, Curd", "VEG"), ("Mirchi bajji, Tea", "VEG"), ("Egg curry, Rice, Chapati", "NONVEG")],
    4: [("Pongal, Vada, Sambar", "VEG"), ("Chicken biryani, Raita", "NONVEG"), ("Sweet corn, Tea", "VEG"), ("Chole, Chapati, Rice", "VEG")],
    5: [("Bread omelette / Bread jam, Milk", "NONVEG"), ("Rice, Dal, Bendi fry, Curd", "VEG"), ("Pav bhaji", "VEG"), ("Fried rice, Gobi Manchurian", "VEG")],
    6: [("Aloo paratha, Curd", "VEG"), ("Special veg meals, Payasam", "VEG"), ("Cutlet, Tea", "VEG"), ("Fish curry, Rice, Chapati", "NONVEG")],
}
ATTEND_RATE = {"BREAKFAST": 0.72, "LUNCH": 0.88, "SNACKS": 0.62, "DINNER": 0.91}

COMPLAINTS = [
    (2, "FOOD", "HIGH", "Rice was undercooked at dinner", "The rice served at dinner yesterday was hard and undercooked. Many of us could not eat it.", "RESOLVED", "Thank you. The cook has been told to check batches before serving."),
    (5, "HYGIENE", "HIGH", "Dirty plates in the dining hall", "Several steel plates still had food stains when we picked them up for lunch.", "IN_PROGRESS", "We are changing the dish-washing routine this week."),
    (8, "MENU", "LOW", "Please add fruit on Sundays", "Could the Sunday menu include a seasonal fruit such as banana or papaya?", "OPEN", ""),
    (11, "FOOD", "MEDIUM", "Curd is too sour", "The curd served with lunch has been very sour for the last three days.", "OPEN", ""),
    (14, "OTHER", "LOW", "Water cooler near the mess is not working", "The water cooler outside the dining hall has no cold water since Monday.", "IN_PROGRESS", "Maintenance has been informed."),
    (17, "HYGIENE", "MEDIUM", "Flies near the serving counter", "There are many flies around the serving counter during dinner.", "OPEN", ""),
    (20, "FOOD", "LOW", "Breakfast timing", "Breakfast runs out of idli by 8:45. Please prepare a little more.", "RESOLVED", "Quantity for breakfast has been increased."),
    (23, "MENU", "MEDIUM", "More variety in snacks", "Snacks repeat the same few items. Could we get some variety?", "OPEN", ""),
    (26, "FOOD", "HIGH", "Stale chapati served", "Chapatis at dinner were cold and dry. This has happened twice this week.", "OPEN", ""),
]


class Command(BaseCommand):
    help = "Create demo data (30 students, 5 rooms, menus, attendance, fees, complaints, waste). Safe to re-run."

    def add_arguments(self, parser):
        parser.add_argument("--password", default="DemoPass@2026",
                            help="Password for all demo accounts (development only).")

    @transaction.atomic
    def handle(self, *args, **opts):
        password_hash = make_password(opts["password"])
        now = timezone.localtime()
        today = now.date()

        sessions = {s.code: s for s in MealSession.objects.all()}
        if len(sessions) < 4:
            self.stderr.write("Meal sessions are missing. Run `python manage.py migrate` first.")
            return

        def account(username, role, first, last):
            user, created = User.objects.get_or_create(
                username=username, defaults={"first_name": first, "last_name": last, "password": password_hash})
            Profile.objects.get_or_create(user=user, defaults={"role": role})
            return user

        admin = account("demo_admin", Role.ADMIN, "Warden", "Demo")
        staff = account("demo_staff", Role.STAFF, "Mess", "Staff")

        rooms = [HostelRoom.objects.get_or_create(number=str(101 + i), defaults={"block": "A", "capacity": 6})[0]
                 for i in range(5)]

        students = []
        for i, name in enumerate(NAMES):
            sid = f"HM2026{i + 1:03d}"
            first, _, last = name.partition(" ")
            username = "demo_student" if i == 0 else sid.lower()
            user = account(username, Role.STUDENT, first, last)
            student, _ = Student.objects.get_or_create(student_id=sid, defaults={
                "full_name": name, "department": DEPTS[i % 5], "year": i % 4 + 1, "room": rooms[i // 6],
                "contact": f"+91 90000 {i + 1:05d}", "email": f"{sid.lower()}@demo.example", "user": user})
            if student.user_id is None:
                student.user = user
                student.save(update_fields=["user"])
            MessRegistration.objects.get_or_create(student=student, defaults={
                "is_active": i not in (27, 28), "diet": "NONVEG" if i % 3 == 0 else "VEG"})
            students.append(student)
        active = [s for s in students if s.registration.is_active]

        # Menus: 14 days back to 7 days ahead
        for offset in range(-14, 8):
            day = today + timedelta(days=offset)
            for code, (items, cat) in zip(["BREAKFAST", "LUNCH", "SNACKS", "DINNER"], MENU[day.weekday()]):
                Menu.objects.update_or_create(date=day, session=sessions[code],
                                              defaults={"items": items, "category": cat, "updated_by": admin})

        # Attendance + food waste for the last 14 days (today only for meals already started)
        for offset in range(-14, 1):
            day = today + timedelta(days=offset)
            for code, session in sessions.items():
                if day == today and now.time() < session.start_time:
                    continue
                rows = [MealAttendance(student=s, session=session, date=day, marked_by=staff) for s in active
                        if random.Random(f"{s.student_id}-{day}-{code}").random() < ATTEND_RATE[code]]
                MealAttendance.objects.bulk_create(rows, ignore_conflicts=True)
                attended = MealAttendance.objects.filter(date=day, session=session).count()
                extra = 0.04 + random.Random(f"waste-{day}-{code}").random() * 0.22
                prepared = math.ceil(attended * (1 + extra))
                FoodWasteRecord.objects.update_or_create(date=day, session=session, defaults={
                    "prepared": prepared, "served": attended, "leftover": prepared - attended,
                    "notes": "Demo data", "recorded_by": staff})

        # Planned absences (tomorrow and the day after)
        for idx, days_ahead, code in [(3, 1, "LUNCH"), (3, 1, "DINNER"), (5, 1, "DINNER"), (8, 2, "LUNCH"),
                                      (13, 1, "BREAKFAST"), (13, 1, "LUNCH"), (19, 2, "DINNER")]:
            PlannedAbsence.objects.get_or_create(student=students[idx], date=today + timedelta(days=days_ahead),
                                                 session=sessions[code], defaults={"reason": "Home visit"})

        # Fees and simulated payments: this month and the previous two
        this_month = today.replace(day=1)
        for back in (2, 1, 0):
            y, m = divmod(this_month.year * 12 + this_month.month - 1 - back, 12)
            month = this_month.replace(year=y, month=m + 1)
            for i, s in enumerate(active):
                fee, _ = MessFee.objects.get_or_create(student=s, month=month, defaults={"amount": Decimal("3000")})
                pattern = (i + back) % 5
                pay_day = min(month + timedelta(days=3 + i % 15), today)
                plan = [(Decimal("3000"), "A")] if pattern in (0, 1, 4) else [(Decimal("1500"), "A")] if pattern == 2 else []
                if back == 0 and pattern == 4:
                    plan = []
                for amount, tag in plan:
                    Payment.objects.get_or_create(reference=f"DEMO-{s.student_id}-{month:%Y%m}-{tag}", defaults={
                        "fee": fee, "amount": amount, "paid_on": pay_day,
                        "method": ["CASH", "UPI", "CARD"][i % 3], "recorded_by": admin})
            for cat, desc, amt in [("GROCERY", "Rice, dal and flour", 52000), ("PRODUCE", "Vegetables and fruit", 21000),
                                   ("DAIRY", "Milk, curd and eggs", 14500), ("GAS", "LPG cylinders", 9800),
                                   ("STAFF", "Cook and helper wages", 36000)]:
                MessExpense.objects.get_or_create(date=min(month + timedelta(days=9), today), category=cat, description=desc,
                                                  defaults={"amount": Decimal(amt), "recorded_by": admin})

        # Complaints
        for n, (idx, cat, prio, subject, text, status, response) in enumerate(COMPLAINTS):
            c, created = Complaint.objects.get_or_create(student=students[idx], subject=subject, defaults={
                "category": cat, "priority": prio, "description": text, "status": status, "response": response,
                "responded_by": admin if response else None})
            if created:
                Complaint.objects.filter(pk=c.pk).update(created_at=now - timedelta(days=n * 2 + 1))

        self.stdout.write(self.style.SUCCESS("Demo data ready."))
        self.stdout.write("Demo logins (development only - change before any deployment):")
        self.stdout.write(f"  Admin / Warden : demo_admin    / {opts['password']}")
        self.stdout.write(f"  Mess staff     : demo_staff    / {opts['password']}")
        self.stdout.write(f"  Student        : demo_student  / {opts['password']}")
        self.stdout.write("  Other students : hm2026002 ... hm2026030 (same password)")
