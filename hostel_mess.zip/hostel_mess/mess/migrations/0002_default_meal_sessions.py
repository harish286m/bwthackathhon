from datetime import time

from django.db import migrations

SESSIONS = [
    ("BREAKFAST", "Breakfast", time(7, 30), time(9, 30), 1),
    ("LUNCH", "Lunch", time(12, 30), time(14, 30), 2),
    ("SNACKS", "Snacks", time(17, 0), time(18, 0), 3),
    ("DINNER", "Dinner", time(19, 30), time(21, 30), 4),
]


def create_sessions(apps, schema_editor):
    MealSession = apps.get_model("mess", "MealSession")
    for code, name, start, end, order in SESSIONS:
        MealSession.objects.get_or_create(
            code=code, defaults={"name": name, "start_time": start, "end_time": end, "order": order})


class Migration(migrations.Migration):
    dependencies = [("mess", "0001_initial")]
    operations = [migrations.RunPython(create_sessions, migrations.RunPython.noop)]
