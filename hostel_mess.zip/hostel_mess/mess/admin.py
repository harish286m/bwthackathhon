from django.contrib import admin

from . import models

for model in (models.Profile, models.HostelRoom, models.Student, models.MessRegistration, models.MealSession,
              models.Menu, models.MealAttendance, models.MessFee, models.Payment, models.Complaint,
              models.FoodWasteRecord, models.PlannedAbsence, models.MessExpense, models.AuditLog):
    admin.site.register(model)
