"""Forms with server-side validation."""
from datetime import datetime
from decimal import Decimal

from django import forms
from django.utils import timezone

from .models import (Complaint, FoodWasteRecord, HostelRoom, MealSession, Menu, MessExpense, MessRegistration,
                     Payment, Student)

DATE_WIDGET = forms.DateInput(format="%Y-%m-%d", attrs={"type": "date"})


class Bootstrap:
    """Adds Bootstrap classes to every widget."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            widget = field.widget
            if isinstance(widget, forms.CheckboxSelectMultiple):
                css = "form-check-input"
            elif isinstance(widget, forms.CheckboxInput):
                css = "form-check-input"
            elif isinstance(widget, forms.Select):
                css = "form-select"
            else:
                css = "form-control"
            widget.attrs["class"] = f"{widget.attrs.get('class', '')} {css}".strip()


class StudentForm(Bootstrap, forms.ModelForm):
    mess_registered = forms.BooleanField(required=False, initial=True, label="Registered for the mess")
    diet = forms.ChoiceField(choices=MessRegistration.Diet.choices, label="Diet preference")

    class Meta:
        model = Student
        fields = ["student_id", "full_name", "department", "year", "room", "contact", "email"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        reg = getattr(self.instance, "registration", None) if self.instance.pk else None
        if reg:
            self.fields["mess_registered"].initial = reg.is_active
            self.fields["diet"].initial = reg.diet

    def clean_student_id(self):
        return self.cleaned_data["student_id"].strip().upper()

    def clean_full_name(self):
        name = " ".join(self.cleaned_data["full_name"].split())
        if len(name) < 3:
            raise forms.ValidationError("Enter the student's full name.")
        return name

    def clean(self):
        data = super().clean()
        room = data.get("room")
        if room:
            others = room.students.exclude(pk=self.instance.pk).count()
            if others >= room.capacity:
                self.add_error("room", f"Room {room} is full ({room.capacity} beds).")
        return data

    def save(self, commit=True):
        student = super().save(commit)
        if commit:
            reg, _ = MessRegistration.objects.get_or_create(student=student)
            reg.is_active = self.cleaned_data["mess_registered"]
            reg.diet = self.cleaned_data["diet"]
            reg.save()
        return student


class RoomForm(Bootstrap, forms.ModelForm):
    class Meta:
        model = HostelRoom
        fields = ["number", "block", "capacity"]


class MenuForm(Bootstrap, forms.ModelForm):
    class Meta:
        model = Menu
        fields = ["items", "category"]
        widgets = {"items": forms.Textarea(attrs={"rows": 3})}

    def clean_items(self):
        items = self.cleaned_data["items"].strip()
        if len(items) < 3:
            raise forms.ValidationError("List at least one dish.")
        return items


class FeeGenerateForm(Bootstrap, forms.Form):
    month = forms.CharField(widget=forms.TextInput(attrs={"type": "month"}), label="Billing month")
    amount = forms.DecimalField(min_value=Decimal("1"), max_digits=8, decimal_places=2, label="Fee per student (Rs.)")

    def clean_month(self):
        try:
            return datetime.strptime(self.cleaned_data["month"], "%Y-%m").date()
        except ValueError:
            raise forms.ValidationError("Choose a valid month.")


class PaymentForm(Bootstrap, forms.ModelForm):
    class Meta:
        model = Payment
        fields = ["amount", "paid_on", "method", "reference"]
        widgets = {"paid_on": DATE_WIDGET}
        help_texts = {"reference": "Any receipt or transaction number. Never enter card or bank details."}

    def __init__(self, *args, fee, **kwargs):
        self.fee = fee
        super().__init__(*args, **kwargs)
        self.fields["paid_on"].initial = timezone.localdate()

    def clean_amount(self):
        amount = self.cleaned_data["amount"]
        if amount <= 0:
            raise forms.ValidationError("Amount must be greater than zero.")
        if amount > self.fee.balance:
            raise forms.ValidationError(f"Amount exceeds the pending balance of Rs. {self.fee.balance}.")
        return amount

    def clean_paid_on(self):
        value = self.cleaned_data["paid_on"]
        if value > timezone.localdate():
            raise forms.ValidationError("Payment date cannot be in the future.")
        return value


class ExpenseForm(Bootstrap, forms.ModelForm):
    class Meta:
        model = MessExpense
        fields = ["date", "category", "description", "amount"]
        widgets = {"date": DATE_WIDGET}

    def clean_date(self):
        if self.cleaned_data["date"] > timezone.localdate():
            raise forms.ValidationError("Date cannot be in the future.")
        return self.cleaned_data["date"]


class ComplaintForm(Bootstrap, forms.ModelForm):
    class Meta:
        model = Complaint
        fields = ["category", "priority", "subject", "description"]
        widgets = {"description": forms.Textarea(attrs={"rows": 4})}

    def clean_description(self):
        text = self.cleaned_data["description"].strip()
        if len(text) < 10:
            raise forms.ValidationError("Please describe the issue in a little more detail.")
        return text


class ComplaintResponseForm(Bootstrap, forms.ModelForm):
    class Meta:
        model = Complaint
        fields = ["status", "response"]
        widgets = {"response": forms.Textarea(attrs={"rows": 4})}

    def clean(self):
        data = super().clean()
        if data.get("status") == Complaint.Status.RESOLVED and not data.get("response", "").strip():
            self.add_error("response", "Add a response before marking the complaint as resolved.")
        return data


class FoodWasteForm(Bootstrap, forms.ModelForm):
    class Meta:
        model = FoodWasteRecord
        fields = ["date", "session", "prepared", "served", "leftover", "notes"]
        widgets = {"date": DATE_WIDGET}

    def clean_date(self):
        if self.cleaned_data["date"] > timezone.localdate():
            raise forms.ValidationError("Date cannot be in the future.")
        return self.cleaned_data["date"]

    def clean_prepared(self):
        if self.cleaned_data["prepared"] < 1:
            raise forms.ValidationError("Enter the number of meals prepared.")
        return self.cleaned_data["prepared"]


class AbsenceForm(Bootstrap, forms.Form):
    date = forms.DateField(widget=DATE_WIDGET)
    sessions = forms.ModelMultipleChoiceField(queryset=MealSession.objects.all(),
                                              widget=forms.CheckboxSelectMultiple, label="Meals you will skip")
    reason = forms.CharField(max_length=120, required=False)

    def clean(self):
        data = super().clean()
        day, sessions = data.get("date"), data.get("sessions")
        if day and sessions:
            now = timezone.localtime()
            if day < now.date():
                self.add_error("date", "Choose today or a future date.")
            elif day == now.date():
                started = [s.name for s in sessions if now.time() >= s.start_time]
                if started:
                    self.add_error("sessions", f"Too late to skip today's {', '.join(started)}.")
        return data
