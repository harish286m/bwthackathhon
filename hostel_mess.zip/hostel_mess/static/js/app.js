(function () {
  var PALETTE = ["#14532d", "#2f9e5b", "#e0a526", "#c8553d", "#3b82a0", "#8a6bbe"];

  // Sidebar toggle (mobile)
  var toggle = document.getElementById("sidebarToggle"), side = document.getElementById("sidebar");
  if (toggle && side) toggle.addEventListener("click", function () { side.classList.toggle("open"); });

  // Charts: <canvas data-chart="json-script-id"> + {{ config|json_script:"json-script-id" }}
  document.querySelectorAll("canvas[data-chart]").forEach(function (canvas) {
    var node = document.getElementById(canvas.dataset.chart);
    if (!node || typeof Chart === "undefined") return;
    var cfg = JSON.parse(node.textContent), round = cfg.type === "doughnut";
    var datasets = cfg.datasets.map(function (d, i) {
      var colour = PALETTE[i % PALETTE.length];
      d.backgroundColor = round ? PALETTE : colour;
      d.borderColor = round ? "#fff" : colour;
      if (cfg.type === "line") { d.tension = 0.3; d.spanGaps = true; d.backgroundColor = colour + "22"; d.fill = true; }
      return d;
    });
    var opts = { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: datasets.length > 1 || round } } };
    if (!round) opts.scales = { x: { stacked: !!cfg.stacked }, y: { stacked: !!cfg.stacked, beginAtZero: true } };
    new Chart(canvas, { type: cfg.type, data: { labels: cfg.labels, datasets: datasets }, options: opts });
  });

  // Confirm dialogs: <form data-confirm="Message">
  document.querySelectorAll("form[data-confirm]").forEach(function (form) {
    form.addEventListener("submit", function (e) { if (!window.confirm(form.dataset.confirm)) e.preventDefault(); });
  });

  // Attendance page: live filter + select all / clear
  var filter = document.getElementById("rosterFilter");
  if (filter) filter.addEventListener("input", function () {
    var q = filter.value.toLowerCase();
    document.querySelectorAll("#roster tbody tr").forEach(function (tr) { tr.hidden = tr.textContent.toLowerCase().indexOf(q) === -1; });
  });
  document.querySelectorAll("[data-check]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      document.querySelectorAll("#roster tbody tr:not([hidden]) input[type=checkbox]").forEach(function (c) { c.checked = btn.dataset.check === "all"; });
    });
  });
})();
